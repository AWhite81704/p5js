function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(10);
  colorMode(RGB, 255, 255, 255, 1);
  
  fill(255, 112, 41);
noStroke();
  triangle(325, 290, 325, 300, 350, 295);
  
fill(255, 204, 0);
  ellipse(200, 200, 100, 100);

noFill();
  stroke(255, 204, 0);
  strokeWeight(2);
  arc(200, 200, 150, 150, 0, HALF_PI);
  arc(200, 200, 180, 180, PI, QUARTER_PI);
    arc(200, 200, 130, 130, PI, QUARTER_PI);
  
fill(250, 249, 242);
noStroke();
  quad(300, 300, 310, 290, 325, 290, 325, 300)
  

stroke(235, 230, 230)
beginShape();
curveVertex(350, 295);
curveVertex(350, 295);
curveVertex(390, 275);
curveVertex(440, 270);
curveVertex(350, 295);
curveVertex(350, 295);
endShape();
  
  
}
