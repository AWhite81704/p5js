let click = 0;
let x = 0;
let y = 0;
let color1 = 0;
let color2 = 0;
let color3 = 0;
function setup() {
  createCanvas(400, 400);
  colorMode(RGB, 255, 255, 255, 1);
  }
  


function draw() {
    if(mouseIsPressed === true) {
    if (color1 < 255) {
      color1 = color1+1;}
    if (color2 < 255) {
      color2 = color2+5;}
    if (color3 < 255){
      color3 = color3+10;}
    }
  if (keyIsPressed === true) {
  if (click < TWO_PI) {
      click = click+0.1;
  } else {
   click = 0;
  }
  }
   y = y - 1;
  if (y < 0) {
    y = height;
  }
  x = x - 1;
  if (x < 0) {
    x = height;
  }
  background(0);
  stroke(x, y, 100, 1);
      for (let variableX = 50; variableX <= 400; variableX += 50) {
    line(variableX, 0, variableX, height);
  }
  stroke(color1, color2, color3, 1);
  line(400-x, 400-y, x, y);
  noStroke();
  fill(255, 204, 0);
  ellipse(200, 200, 100, 100);
  noFill();
  stroke(255, 204, 0);
  arc(200, 200, 110, 110, 0, click);
}