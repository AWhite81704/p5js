
var num = 60;

var x = [];

var y = [];

let pacArc1 = 0;
let pacArc2 = 0;
let distance = 0;

function setup() {

	createCanvas(800, 1200);
	noStroke();

	for (var i = 0; i < num; i++) {

		x[i] = 0;

		y[i] = 0;
    
    distance = sqrt((mouseX-x[59])^2+(mouseY-y[59])^2)
      console.log(distance);

	}

}

function draw() {

	background(0);
  
	for (var i = num-1; i > 0; i--) {

		x[i] = x[i-1];

		y[i] = y[i-1];
	}

	x[0] = mouseX;
      print(x.length);
	y[0] = mouseY;

	for (var i = 0; i < num; i++) {

          fill(255, 255, 0);
        
		arc(x[59], y[59], 40, 40, PI/4, 7*PI/4);

      
	}
}




